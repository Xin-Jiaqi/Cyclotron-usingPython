﻿import math as math
import numpy as np
import matplotlib.pyplot as plt

"""
<回旋加速器原理>
  洛伦兹力表达式 F = q v^B = m dv/dt
  加速电场中受力表达式 F = E q = m dv/dt
  
  在均匀磁场中：
     轨迹是圆的
     速度不变，只改变方向
     粒子匀速圆周运动半径表达式 r = m v /(B q)
     周期的表达式 T = 2 PI / ( B q/m )

  在匀强电场中：
     轨迹是抛物线或直线
     加速度恒定，其表达式为 a = E q/m
     Delta v = a Delta t
"""

#引入粒子
class Particle:
	def __init__(self, pos, vel, mass, charge):
		self.pos = pos
		self.vel = vel
		self.mass = mass
		self.charge = charge

#光速
speed_of_light = 3.0E08

#设定研究的粒子为质子，初速度为2%光速
proton = Particle([0.00, 0.0, 0.0], [0.05*speed_of_light, 0.0, 0.0], 1.67E-27, +1.60E-19)

#dipole = Dipole(1.0, [100.0, 0.0, 0.0], [0.0, 0.0, 100.0])

#电场强度与磁感应强度参数
e_field = [5000000.0, 0.0, 0.0]
magn_uniform_field = [0.0, 0.0, -1.5]

b = np.linalg.norm(magn_uniform_field)#磁场强度
v_i = np.linalg.norm(proton.vel)#粒子初始速度
expected_radius = v_i / ( b * (proton.charge/proton.mass ) )
print ('expected initial radius is ', expected_radius, 'meters')#初始半径
spacing = 0.5 * expected_radius#设置加速电场“缝隙”宽度

expected_period = 2.0*math.pi/( b * (proton.charge/proton.mass ) )
print ('expected period is ', expected_period, 'seconds')#运动周期（4.372049776245796e-08 seconds）
number_of_points = 400
guess_for_delta_t = expected_period / number_of_points#delta t趋于0
print ('delta_t would be', guess_for_delta_t, 'for', number_of_points,'points')


count = 0#计算在加速电场“缝隙”内迭代次数

jumps =0#统计粒子跳转次数
jumps_max = 51#模拟回旋加速器的最大半径

#计算粒子在回旋加速器不同位置中的加速度
def em_acceleration( q_over_m, position, velocity ):
#	b = dipole.flux_density(position) + magn_uniform_field
#	a = np.cross(velocity, b) + e_field
#	a = a * q_over_m
	global count, jumps

	if jumps >= jumps_max:
		a = 0#粒子运动半径达到加速器最大半径，粒子出加速器：
	else:
		if position[0] >= 0 or position[0] <= -spacing :
			a = np.cross(velocity, magn_uniform_field)
			a = a * q_over_m
			if count:
				print(" current velocity:%1.4f speed of light"%(np.linalg.norm(velocity) / speed_of_light) )
				count = 0
				jumps = jumps + 1
		else:
			a = np.array(e_field)
			a = a * q_over_m
			if position[1] > expected_radius:
				a = -a
			count = count + 1

	return a


#欧拉法
def euler(particle, max_iter, delta_t):
	q_over_m = particle.charge / particle.mass
	#质子核质比
	results = []
	i = 0
	
	for i in range(max_iter):
		i += 1
		p = np.array(particle.pos)#已知位置
		v = np.array(particle.vel)#已知速度
		a = em_acceleration( q_over_m, p, v )#计算粒子加速度
		p = p + delta_t * v#根据v计算x
		v = v + delta_t * a#根据a计算v
		particle.pos = p
		particle.vel = v
		#print p
		results.append(p)
	return results

#龙格-库塔法
def rk4(particle, max_iter, delta_t):
	q_over_m = particle.charge / particle.mass
	#质子核质比

	results = []
	i = 0
	p0 = np.array(particle.pos)
	v0 = np.array(particle.vel)

	for i in range(max_iter):
		i += 1
		p1 = p0
		v1 = v0
		a1 = delta_t * em_acceleration( q_over_m, p1, v1 )
		v1 = delta_t * v1#这是要加权
		
		p2 = p0 + (v1 * 0.5)
		v2 = v0 + (a1 * 0.5)
		a2 = delta_t * em_acceleration( q_over_m, p2, v2 )
		v2 = delta_t * v2
		
		p3 = p0 + (v2 * 0.5)
		v3 = v0 + (a2 * 0.5)
		a3 = delta_t * em_acceleration( q_over_m, p3, v3 )
		v3 = delta_t * v3
		
		p4 = p0 + v3
		v4 = v0 + a3
		a4 = delta_t * em_acceleration( q_over_m, p4, v4 )
		v4 = delta_t * v4
		
		dv = (a1 + 2.0 * (a2 + a3) + a4)
		v0 = v0 + dv / 6.0
		
		dp = (v1 + 2.0 * (v2 + v3) + v4)
		p0 = p0 + dp / 6.0
		#四个斜率取平均时，中点的斜率有更大的权值
		
		if p0[0] >= -10.0 * expected_radius and p0[0] <= 10.0 * expected_radius and \
                   p0[1] >= -10.0 * expected_radius and p0[1] <= 10.0 * expected_radius :
#保存下来速度、位置
			p0[2] = np.linalg.norm(v0)
			results.append(p0.copy())
			p0[2] = 0.0

	return results
	

#matplotlib PARAMS
fig1 = plt.figure()
ax1  = fig1.add_subplot(1,1,1)

fig2 =  plt.figure()
ax2  = fig2.add_subplot(1,1,1)

#描绘工作
def part_plot(particle, max_iter, method, color):

#初始位置用黄色来标记
	x = []
	y = []

	x.append(particle.pos[0])
	y.append(particle.pos[1])
	ax1.scatter(x, y, color = 'yellow')

	z = []
	v0 = np.linalg.norm(particle.vel)
# z = []用来保存速度
	z.append(v0)

	print ("initial position", x[0],y[0],z[0])
	print(" initial velocity %1.4f the speed of light"%(v0 / speed_of_light) )

	delta_t = guess_for_delta_t
	if method == 'euler':
		results = euler(particle, max_iter, delta_t)
	elif method == 'rk4':
		results = rk4(particle, max_iter, delta_t)

#现在就可以用 蓝色 来描绘粒子在匀强电场中的轨迹、 红色 来描绘粒子在匀强磁场中的轨迹
	xc = []
	yc = []
	x = []
	y = []
	for p in results:
		z.append(p[2])
		if p[0] >= 0 or p[0] <= -spacing :
			if len(xc) :
				ax1.plot(xc,yc, color='blue',linewidth=0.95)
				xc = []
				yc = []
			x.append(p[0])
			y.append(p[1])
		else:
			if len(xc) :
				ax1.plot(x,y, color='green',linewidth=0.95)
				x = []
				y = []
			xc.append(p[0])
			yc.append(p[1])

	if len(xc) :
		ax1.plot(xc,yc, color='blue',linewidth=0.95)
		xc = []
		yc = []
	if len(x) :
		ax1.plot(x,y, color='green',linewidth=0.95)
		x = []
		y = []

	print ("number of jumps is", jumps)
	num_points = len(z)
#	print "final position", x[num_points-1],y[num_points-1],z[num_points-1]
	print ('number of points is', num_points, ' * delta_t is total time = ', delta_t * num_points)

	b = np.linalg.norm(magn_uniform_field)
	e = np.linalg.norm(e_field)
	v1 = z[len(z)-1]

	ax1.set_title("Particle trajectories in cyclotron")
	ax1.set_xlabel("X(m)")
	ax1.set_ylabel("Y(m)")
	comment = "porton:\n mass=" + str(proton.mass) + " kg\n charge=" + str(proton.charge) + " C\n initial V=" + str(v0) + " m/s"
	comment = comment + "\n final V=" + str(v1) + " m/s"
	comment = comment + "\n\nUniform B=" + str(b) + "T"
	comment = comment + "\nUniform E=" + str(e) + " V/m"
	comment = comment + "\n\nspacing =" + str(spacing) + "m"
	ax1.text(-10.0*expected_radius, -2.*expected_radius, comment)

	t = np.linspace(0, len(z)*delta_t, len(z))
	ax2.plot(t, z )
	ax2.set_title("particle's v/t image")
	ax2.set_xlabel("t(sec)")
	ax2.set_ylabel("v(m/s)")

part_plot(proton, 50000, 'rk4', 'blue')

plt.show()